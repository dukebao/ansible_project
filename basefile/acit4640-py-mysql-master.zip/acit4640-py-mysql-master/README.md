## Example web app for ACIT4640 (Systems and Networks Provisioning)

The app is built on three components:
* the `frontend` (HTML file with inline vanilla JS)
* the `backend` (Python/Flask app)
* the database (MySQL)

[Application setup (live demo)](https://youtu.be/msfqAOBcKYo)